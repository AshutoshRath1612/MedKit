import React from "react";

const Chat = () => {
    return ( 
        <div>

        </div>
     );
}
 
export default Chat;